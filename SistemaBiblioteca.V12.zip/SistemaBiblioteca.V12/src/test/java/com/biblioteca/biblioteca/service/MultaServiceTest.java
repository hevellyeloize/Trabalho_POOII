package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.model.Emprestimo;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class MultaServiceTest {

    @Test
    void deveRejeitarValorNegativoParaMulta() {
        // Arrange
        MultaService service = new MultaService();
        Emprestimo emprestimo = new Emprestimo(1, null, null,
                LocalDate.of(2026, 11, 1), LocalDate.of(2026, 11, 10), "Atrasado");

        // Act & Assert
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> service.salvar(null, emprestimo, "-10,50", "Pendente"),
                "Deve lançar IllegalArgumentException quando o valor da multa for negativo."
        );

        assertEquals("O valor da multa não pode ser negativo.", excecao.getMessage(),
                "A mensagem de erro deve indicar que o valor da multa não pode ser negativo.");
    }
}