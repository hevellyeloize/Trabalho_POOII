package com.biblioteca.biblioteca.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class MultaTest {

    @Test
    void deveCalcularMultaQuandoEntregaEstiverAtrasada() {
        // Arrange
        LocalDate dataEmprestimo = LocalDate.of(2026, 11, 1);
        LocalDate dataPrevistaDevolucao = LocalDate.of(2026, 11, 10);
        LocalDate dataEntregaReal = LocalDate.of(2026, 11, 15); // 5 dias de atraso

        Emprestimo emprestimo = new Emprestimo(1, null, null, dataEmprestimo, dataPrevistaDevolucao, "Atrasado");
        Multa multa = new Multa(1, emprestimo, 0.0, false);

        // Act
        multa.calcularMultaPorAtraso(2.50, dataEntregaReal);

        // Assert
        assertEquals(12.50, multa.getValor(), 0.001,
                "Para 5 dias de atraso a R$ 2,50/dia, o valor da multa deve ser R$ 12,50.");
    }

    @Test
    void deveZerarMultaQuandoEntregaForNoPrazoOuAntecipada() {
        // Arrange
        LocalDate dataEmprestimo = LocalDate.of(2026, 11, 1);
        LocalDate dataPrevistaDevolucao = LocalDate.of(2026, 11, 10);
        LocalDate dataEntregaNoPrazo = LocalDate.of(2026, 11, 10);

        Emprestimo emprestimo = new Emprestimo(2, null, null, dataEmprestimo, dataPrevistaDevolucao, "Devolvido");
        Multa multa = new Multa(2, emprestimo, 50.0, false);

        // Act
        multa.calcularMultaPorAtraso(2.50, dataEntregaNoPrazo);

        // Assert
        assertEquals(0.0, multa.getValor(), 0.001,
                "Quando a entrega ocorre na data prevista ou antes, a multa deve ser zerada (0.0).");
    }

    @Test
    void naoDeveAlterarValorQuandoEmprestimoForNulo() {
        // Arrange
        Multa multa = new Multa(3, null, 15.0, false);

        // Act
        multa.calcularMultaPorAtraso(2.50, LocalDate.of(2026, 11, 20));

        // Assert
        assertEquals(15.0, multa.getValor(), 0.001,
                "Se o empréstimo associado à multa for nulo, o cálculo não deve alterar o valor existente.");
    }
}