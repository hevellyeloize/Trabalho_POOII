package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.model.Livro;
import com.biblioteca.biblioteca.model.Usuario;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class EmprestimoServiceTest {

    @Test
    void deveRejeitarDataDevolucaoAnteriorADataEmprestimo() {
        // Arrange
        EmprestimoService service = new EmprestimoService();
        Usuario usuario = new Usuario(1, "Arthur", "arthur@email.com", "42999999999");
        Livro livro = new Livro(1, "Clean Code", "Robert C. Martin", 2008, 3);
        LocalDate dataEmprestimo = LocalDate.of(2026, 11, 20);
        LocalDate dataDevolucaoInvalida = LocalDate.of(2026, 11, 15);

        // Act & Assert
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> service.salvar(null, usuario, livro, dataEmprestimo, dataDevolucaoInvalida, "Ativo"),
                "Deve lançar IllegalArgumentException quando a data de devolução for anterior à data de empréstimo."
        );

        assertEquals("A data de devolução não pode ser anterior à data do empréstimo.", excecao.getMessage(),
                "A mensagem de erro deve informar que a data de devolução não pode ser anterior ao empréstimo.");
    }
}