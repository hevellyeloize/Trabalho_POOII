package com.biblioteca.biblioteca.strategy;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MultaPromocionalStrategyTest {

    @Test
    void deveCalcularMultaPromocionalComTaxaReduzida() {
        // Arrange
        CalculoMultaStrategy strategy = new MultaPromocionalStrategy();

        // Act
        double resultado = strategy.calcular(7);

        // Assert
        assertEquals(7.00, resultado, 0.001,
                "A estratégia promocional deve cobrar R$ 1,00 por dia (7 dias = R$ 7,00).");
    }
}