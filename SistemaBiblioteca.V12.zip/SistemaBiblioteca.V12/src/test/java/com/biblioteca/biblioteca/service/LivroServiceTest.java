package com.biblioteca.biblioteca.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LivroServiceTest {

    @Test
    void deveLancarExcecaoQuandoAnoOuQuantidadeNaoForemNumericos() {
        // Arrange
        LivroService service = new LivroService();

        // Act & Assert
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> service.salvar(null, "Dom Casmurro", "Machado de Assis", "anoInvalido", "5"),
                "Deve lançar IllegalArgumentException quando o ano informado não for um número inteiro válido."
        );

        assertTrue(excecao.getMessage().contains("números válidos"),
                "A mensagem da exceção deve orientar sobre números válidos para Ano e Quantidade.");
    }
}