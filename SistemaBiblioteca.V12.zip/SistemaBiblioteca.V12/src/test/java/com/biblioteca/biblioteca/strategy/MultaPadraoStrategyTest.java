package com.biblioteca.biblioteca.strategy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MultaPadraoStrategyTest {

    private CalculoMultaStrategy strategy;

    @BeforeEach
    void preparar() {
        strategy = new MultaPadraoStrategy();
    }

    @Test
    void deveCalcularMultaPadraoParaDiasPositivos() {
        // Arrange
        long diasAtraso = 4;

        // Act
        double resultado = strategy.calcular(diasAtraso);

        // Assert
        assertEquals(10.00, resultado, 0.001,
                "A estratégia padrão deve cobrar R$ 2,50 por dia (4 dias = R$ 10,00).");
    }

    @Test
    void deveRetornarZeroQuandoNaoHouverDiasDeAtraso() {
        // Arrange & Act
        double resultado = strategy.calcular(0);

        // Assert
        assertEquals(0.0, resultado, 0.001,
                "Com 0 dias de atraso, o valor calculado pela estratégia padrão deve ser 0.0.");
    }
}